DSDPlus -r1 -i20001 >>1R-log.txt
