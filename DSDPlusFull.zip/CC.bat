DSDPlus -rc -i20001 >>CC.log
