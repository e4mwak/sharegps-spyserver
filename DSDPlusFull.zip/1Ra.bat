DSDPlus -F2 -r1 -i20002 >>1Ra-log.txt
