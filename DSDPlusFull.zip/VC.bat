DSDPlus -rv -i20002 >>VC.log
